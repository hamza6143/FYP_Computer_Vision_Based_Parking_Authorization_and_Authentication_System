#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h> 
#include <LiquidCrystal_I2C.h>
#include <Servo.h>
#include <Keypad.h>

// Pins for RFID
#define SS_PIN 10
#define RST_PIN 9

MFRC522 rfid(SS_PIN, RST_PIN);
LiquidCrystal_I2C lcd(0x27, 16, 2);
Servo gateServo;

// --- KEYPAD CONFIGURATION ---
const byte ROWS = 4; 
const byte COLS = 4; 
char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {A1, 8, 7, 6}; 
byte colPins[COLS] = {5, 4, 3, 2}; 

Keypad myKeypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

// --- ADJUSTABLE PARAMETERS ---
int closeAngle = 0;      
int openAngle = 110;     
unsigned long stayOpenTime = 8000; 

// --- EMERGENCY BYPASS CONFIG ---
const String EMERGENCY_CODE = "2327"; 
String inputCode = "";

// --- STATE MANAGEMENT ---
bool isGateOpen = false;
bool isKeypadBypassActive = false; // Tracks if keypad toggle is active
unsigned long gateOpenStartTime = 0;

void setup() {
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();
  
  gateServo.attach(A0); 
  gateServo.write(closeAngle); 
  
  lcd.init();
  lcd.backlight();
  displayReadyMessage();
}

void loop() {
  // --- 1. AUTOMATIC TIMER CONTROL (Only for RFID/Plate paths) ---
  // If the gate is open via RFID, close it after stayOpenTime.
  // If it's open via Keypad Bypass, ignore this timer entirely.
  if (isGateOpen && !isKeypadBypassActive && (millis() - gateOpenStartTime >= stayOpenTime)) {
    closeGate();
  }

  // --- 2. KEYPAD PROCESSING (TOGGLE BYPASS ENGINE) ---
  char key = myKeypad.getKey();
  if (key) {
    if (key == '#') { 
      if (inputCode == EMERGENCY_CODE) {
        handleKeypadBypassToggle();
      } else {
        lcd.clear();
        lcd.print("INVALID CODE");
        delay(1500);
        if (isKeypadBypassActive) displayBypassActiveMessage(); else displayReadyMessage();
      }
      inputCode = ""; 
    } 
    else if (key == '*') { 
      inputCode = "";
      lcd.clear();
      lcd.print("ENTRY CLEARED");
      delay(1000);
      if (isKeypadBypassActive) displayBypassActiveMessage(); else displayReadyMessage();
    } 
    else {
      // Allow code entry to close or open the gate
      inputCode += key;
      lcd.clear();
      lcd.print("ENTER CODE:");
      lcd.setCursor(0, 1);
      for(int i=0; i<inputCode.length(); i++) lcd.print("*");
    }
  }

  // --- 3. CHECK FOR RFID CARD SCAN (Completely disabled during Keypad Bypass) ---
  if (!isGateOpen && !isKeypadBypassActive && rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    lcd.clear();
    lcd.print("SCANNING...");
    
    for (byte i = 0; i < rfid.uid.size; i++) {
      Serial.print(rfid.uid.uidByte[i] < 0x10 ? "0" : "");
      Serial.print(rfid.uid.uidByte[i], HEX);
    }
    Serial.println();
    
    rfid.PICC_HaltA();
    delay(100); 
  }

  // --- 4. LISTEN FOR PYTHON'S RESPONSE (Completely disabled during Keypad Bypass) ---
  if (!isGateOpen && !isKeypadBypassActive && Serial.available() > 0) {
    char result = Serial.read();
    
    if (result == 'G') {
      openGate("ACCESS GRANTED", "PASS THROUGH", false);
    } 
    else if (result == 'D') {
      lcd.clear();
      lcd.print("ACCESS DENIED");
      lcd.setCursor(0, 1);
      lcd.print("CHECK PLATE/UID");
      delay(3000);
      displayReadyMessage();
    }
  }
}

void openGate(String msg1, String msg2, bool isBypass) {
  lcd.clear();
  lcd.print(msg1);
  lcd.setCursor(0, 1);
  lcd.print(msg2);
  
  // Strip away potential interrupt locks
  gateServo.detach();
  delay(10);
  gateServo.attach(A0);
  
  gateServo.write(openAngle); 
  delay(15); 
  
  isGateOpen = true;
  isKeypadBypassActive = isBypass;
  gateOpenStartTime = millis(); 
}

void closeGate() {
  gateServo.write(closeAngle);
  delay(15);
  isGateOpen = false;
  isKeypadBypassActive = false;
  displayReadyMessage();
}

void handleKeypadBypassToggle() {
  while(Serial.available() > 0) Serial.read(); // Clear serial buffer
  
  if (!isKeypadBypassActive) {
    // Action: Open Gate permanently until toggled off
    Serial.println("EMERGENCY_OVERRIDE_ON"); 
    openGate("EMERGENCY MODE", "BYPASS ACTIVE", true);
  } else {
    // Action: Close Gate and return to normal operation
    Serial.println("EMERGENCY_OVERRIDE_OFF"); 
    lcd.clear();
    lcd.print("BYPASS DEACTIVATED");
    lcd.setCursor(0, 1);
    lcd.print("CLOSING GATE...");
    delay(1500);
    closeGate();
  }
}

void displayReadyMessage() {
  lcd.clear();
  lcd.print(" PARKING SYSTEM ");
  lcd.setCursor(0, 1);
  lcd.print("    READY...    ");
}

void displayBypassActiveMessage() {
  lcd.clear();
  lcd.print("EMERGENCY MODE");
  lcd.setCursor(0, 1);
  lcd.print("BYPASS ACTIVE");
}