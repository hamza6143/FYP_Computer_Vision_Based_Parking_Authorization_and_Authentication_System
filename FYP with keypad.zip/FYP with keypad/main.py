import serial
import cv2
import easyocr
import numpy as np
import re
import os
import ssl
import sqlite3
import time
from datetime import datetime

# --- 1. INITIALIZATION & SSL FIX ---
if (not os.environ.get('PYTHONHTTPSVERIFY', '') and
    getattr(ssl, '_create_unverified_context', None)):
    ssl._create_default_https_context = ssl._create_unverified_context

reader = easyocr.Reader(['en'], gpu=False)

# --- 2. CONFIGURATION ---
DB_NAME = r'C:\Users\User\Desktop\codes\fyp\parking_system.db' 
BLACKLIST = ["SINDH", "PAKISTAN", "GOVT"]

# --- 3. DATABASE SETUP ---
def init_db():
    os.makedirs(os.path.dirname(DB_NAME), exist_ok=True)
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS authorized_users 
                      (uid TEXT PRIMARY KEY, plate_number TEXT)''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS access_logs 
                      (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                       uid TEXT, plate_text TEXT, timestamp TEXT, status TEXT)''')
    
    raw_records = [
        ('4C 3A 73 06', 'BVS 406'),
        ('22 D7 07 5B', 'AFR 024'),
        ('99 65 F5 04', 'ABC 1234'),
        ('D7 ED C5 01', 'LE 0161')
    ]
    cleaned_records = [(r[0].replace(" ", "").upper(), r[1]) for r in raw_records]
    cursor.executemany("INSERT OR REPLACE INTO authorized_users VALUES (?, ?)", cleaned_records)
    conn.commit()
    conn.close()
    print("✅ Database synced and UIDs formatted.")

# --- 4. HELPER FUNCTIONS ---
def clean_and_filter(text):
    clean_text = re.sub(r'[^A-Z0-9]', '', text.upper())
    if clean_text in BLACKLIST or len(clean_text) < 2:
        return None
    return clean_text

def log_to_db(uid, plate, status):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor.execute("INSERT INTO access_logs (uid, plate_text, timestamp, status) VALUES (?, ?, ?, ?)",
                       (uid, plate, now, status))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"⚠️ Database Logging Error: {e}")

def perform_ajrak_ocr(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.bilateralFilter(gray, 11, 17, 17)
    thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                  cv2.THRESH_BINARY_INV, 71, 15)
    results = reader.readtext(thresh)
    detected_parts = []
    for (bbox, text, prob) in results:
        filtered = clean_and_filter(text)
        if filtered and prob > 0.30:
            detected_parts.append(filtered)
    return " ".join(detected_parts), thresh

def verify_and_respond(uid, frame):
    try:
        uid_to_check = uid.replace(" ", "").upper()
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT plate_number FROM authorized_users WHERE uid=?", (uid_to_check,))
        result = cursor.fetchone()
        conn.close()
        
        if not result:
            print(f"❌ ACCESS DENIED")
            if arduino: arduino.write(b'D') 
            log_to_db(uid_to_check, "N/A", "DENIED_UNREGISTERED")
            return

        expected_plate = result[0].replace(" ", "").upper()
        ocr_text, _ = perform_ajrak_ocr(frame)
        ocr_clean = ocr_text.replace(" ", "").upper()
        
        print(f"🔍 Match Found! | OCR Detected: {ocr_text}")

        if expected_plate in ocr_clean:
            print("✅ GRANTED: Opening Gate")
            if arduino: arduino.write(b'G') 
            status = "GRANTED"
        else:
            print("❌ DENIED: Plate Mismatch")
            if arduino: arduino.write(b'D')
            status = "DENIED_PLATE_MISMATCH"

        log_to_db(uid_to_check, ocr_text if ocr_text else "NO_READ", status)
    except Exception as e:
        print(f"❌ Verification Error: {e}")

# --- 5. HARDWARE SETUP ---
init_db()
arduino = None
try:
    arduino = serial.Serial(port='COM5', baudrate=9600, timeout=.1)
    time.sleep(2)
    print("✅ Arduino Connected on COM5.")
except Exception as e:
    print(f"⚠️ Warning: Arduino Connection Failed: {e}")

cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
if not cap.isOpened():
    print("❌ Critical Error: Could not open camera.")
    exit()

# --- 6. MAIN LOOP ---
print("\n--- PARKING SYSTEM ACTIVE ---")

while True:
    ret, frame = cap.read()
    if not ret: break

    cv2.imshow('Live Feed', frame)
    key = cv2.waitKey(1) & 0xFF

    if arduino and arduino.in_waiting > 0:
        raw_data = arduino.readline().decode('utf-8', errors='ignore').strip()
        
        # Keypad Manual Toggle - Open Gate
        if raw_data == "EMERGENCY_OVERRIDE_ON":
            print("\n🚨 EMERGENCY BYPASS: Keypad turned ON. Gate Locked Open.")
            log_to_db("KEYPAD_BYPASS", "BYPASS_ON", "EMERGENCY_OPEN")
            arduino.reset_input_buffer()
            
        # Keypad Manual Toggle - Close Gate
        elif raw_data == "EMERGENCY_OVERRIDE_OFF":
            print("\n🔒 EMERGENCY BYPASS: Keypad turned OFF. System Scanning Restored.")
            log_to_db("KEYPAD_BYPASS", "BYPASS_OFF", "EMERGENCY_CLOSE")
            arduino.reset_input_buffer()
        
        # Standard RFID Mode
        elif len(raw_data) >= 7: 
            print(f"\n📡 RFID Received: {raw_data}")
            verify_and_respond(raw_data, frame)
            arduino.reset_input_buffer()

    if key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
if arduino: arduino.close()